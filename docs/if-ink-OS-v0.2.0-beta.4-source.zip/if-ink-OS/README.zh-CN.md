# if-ink OS

**稳定版 v0.1.7 · 测试版 v0.2.0-beta** · 支持 Markdown 文档的 Pico 固件。仅适用 MindReset Read Pico RDP-G01-W。

[在线刷机与下载](https://yiifanrecyclable.github.io/if-ink-OS/) · [版本与离线包](https://github.com/yiifanrecyclable/if-ink-OS/releases/tag/v0.1.7) · [安装说明](docs/安装说明.md) · [构建与重新链接](BUILDING.md)

- EPUB、TXT、Markdown 离线阅读，支持图片与文字混排、表格、标题字号、粗体、斜体与高亮。
- 坚果云 WebDAV 获取文件列表，按需下载 MD/TXT/EPUB，保存到 TF 卡。
- 自定义 Banner 首页、每日阅读打卡与目标设定、壁纸轮播、最近阅读，以及统一字号、字体和分割线界面。
- 阅读控制面板、书签、目录、可选快捷手势、WiFi 密码记忆、中文/English系统界面及独立在线升级。
- WiFi／热点网页可编辑 Banner 与锁屏、预览实际设备排版、同步电脑TTF字体并管理TF文件。

首次安装用电脑 Chrome/Edge 打开在线刷机页；已有 IF/if-ink OS 的设备可使用 TF 升级包。在线安装不需要 Python。离线 USB 包包含固件及刷写参数，手动刷写需提前准备 Python 和 esptool。TF 卡固定目录为 `books`、`fonts`、`markdown`；首次可下载字体与拼音词库资源包。含更新器的版本可在“设置 → 固件信息 → 在线升级”检查后续版本。同版本无需重复安装。0.1.7已通过完整构建与宿主检查，本版新增功能的最终墨水屏与休眠效果仍需真机验证。

Obsidian 推送插件为独立项目，本固件发布包不包含插件及任何账号配置。坚果云的应用密码在设备设置中手动填写。

基于 [Pico Reader 0.3.3-rc83](https://github.com/wegooo-cell/read-pico-reader)，选择性采用后续 rc88/rc95 的阅读、刷新与存储改进；保留 if-ink OS 的界面与刷新策略。感谢[原作者主页](https://wegooo-cell.github.io/read-pico-reader/)。本项目是独立衍生版本，不是原作者或 MindReset 官方发布。

主体 [Apache-2.0](LICENSE)；epdiy 使用 LGPL-3.0-or-later，其他组件及字体保留原许可。每版同时提供对应源码、固定依赖、实际构建配置和许可包，参见[第三方声明](THIRD_PARTY_NOTICES.md)。

### 阅读进度存储

TF卡可用时，续读位置、阅读百分比和最近阅读顺序保存到卡内的隐藏目录 `.readpico/progress`。请保留该目录；转移整张卡或备份时一并复制。每项记录使用CRC校验双副本，保存时同步并读回校验；写入失败不会显示为保存成功。旧NVS记录继续可读，之后的阅读更新保存到TF，无卡时沿用NVS。设置中的“保存与恢复”包含新进度库，兼容旧备份。旧版尚未成功保存、并已随重启丢失的内存进度无法恢复。

### 图片文件浏览

长按文件或文件夹会从底部导航栏上方展开文件操作卡片，提供重命名、复制、移动和删除；点击右上角关闭或卡片外空白处收起。JPG/JPEG/PNG的宽高比与684×1216相差不超过5%时，卡片还提供“设为息屏壁纸”，成功保存后会替换原来的固定或轮播壁纸。文件操作结果临时显示在顶部中央，约4秒后恢复状态栏。

存储卡管理中的`pictures`和`banner pic`及其子目录可在标题右侧切换列表/缩略图；单击查看图片，长按管理。图片网格最多九项，Banner宽幅网格最多八项，按页显示；模式在本次开机中分别沿用。缩略图支持JPG/JPEG/PNG，首访生成并在`.readpico/thumbnails`缓存；无法解码时保留占位及文件操作。此缓存可单独删除重建，不要删除包含阅读记录的整个`.readpico`目录。五个固定根目录books、markdown、fonts、pictures、banner pic不能改名、复制、移动或删除，内部文件仍按各自规则管理。
