/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 双模式传书生命周期和跨任务状态；存储策略由调用方注入。
 * AP/STA transfer lifecycle and cross-task status; caller supplies storage policy.
 * 冻结：图书仅接收 TXT/EPUB；字体与图片只进入各自固定目录；不依赖页面或图书实现。
 * Frozen: book uploads accept TXT/EPUB only; font and image uploads use fixed directories; no page or book implementation dependency.
 * 冻结：热点网页或停服后的设备触屏可配网；已有WiFi模式不接受远程修改凭据。
 * Frozen: AP webpage or stopped-service device UI may provision; STA rejects remote credential changes.
 */
#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "esp_err.h"
#include "read_pico_transfer_network.h"
#include "read_pico_transfer_editor.h"

#define READ_PICO_TRANSFER_PASSWORD "readpico"
#define READ_PICO_TRANSFER_URL "http://192.168.4.1"

typedef enum {
    READ_PICO_TRANSFER_MODE_AP = 0, ///< 设备热点 / Device hotspot
    READ_PICO_TRANSFER_MODE_STA, ///< 已有 WiFi / Existing WiFi
} read_pico_transfer_mode_t;

typedef enum {
    READ_PICO_TRANSFER_STOPPED, ///< 已停止 / Stopped
    READ_PICO_TRANSFER_STARTING, ///< 启动中 / Starting
    READ_PICO_TRANSFER_READY, ///< 等待上传 / Ready
    READ_PICO_TRANSFER_UPLOADING, ///< 接收中 / Receiving
    READ_PICO_TRANSFER_ERROR, ///< 网络或请求失败 / Network or request failed
} read_pico_transfer_state_t;

typedef struct {
    read_pico_transfer_mode_t mode; ///< 网络模式，默认热点 / Network mode, default AP
    bool network_only; ///< 仅连接已有 WiFi，不启动上传服务或访问存储 / Connect saved WiFi without upload server or storage
    bool use_selected_wifi; ///< 本次手动选网只连接当前选项；默认扫描附近已保存网络 / Honor an explicit choice for this startup; otherwise scan nearby saved networks
    const char *root_dir; ///< 已挂载根目录，start 内复制 / Mounted root, copied by start
    bool is_flash; ///< 内置存储标志 / Internal storage flag
    size_t file_limit; ///< 单文件上限，零表示不限 / Per-file limit, zero means unlimited
    uint64_t (*free_bytes_cb)(void *ctx); ///< 查询可用字节 / Query available bytes
    void *free_bytes_ctx; ///< 回调上下文，stop 前有效 / Callback context valid until stop
    bool (*title_get_cb)(const char *path, char *out, size_t cap); ///< 读取显示书名覆盖 / Read title override
    esp_err_t (*title_set_cb)(const char *path, const char *title); ///< 保存显示书名覆盖 / Save title override
    esp_err_t (*file_changed_cb)(const char *path); ///< 文件提交或删除后清除进度；失败不回滚文件 / Clear progress after commit or deletion; failure never rolls back the file
    esp_err_t (*document_import_cb)(const char *staging, const char *destination); ///< MD 暂存验证及原子入库 / Validate and atomically import staged MD
    esp_err_t (*file_deleted_cb)(const char *path); ///< 网页文件管理删除后的元数据清理 / Metadata cleanup after web file deletion
    esp_err_t (*file_moved_cb)(const char *old_path, const char *new_path, uint32_t size); ///< 网页重命名后的进度与字体路径迁移 / Migrate progress and font selection after rename
    void (*directory_deleted_cb)(const char *path); ///< 删除目录后清理目录设置 / Clear directory settings after deletion
    void (*directory_moved_cb)(const char *old_path, const char *new_path); ///< 重命名目录后更新目录设置 / Update directory settings after rename
    read_pico_transfer_editor_fn editor_cb; ///< UI任务执行网页草稿 / UI task handles web drafts
    bool (*path_write_allowed_cb)(const char *path); ///< 拒绝修改正在使用的Banner资源 / Protect selected banner resources
    bool (*wallpaper_set_cb)(const char *path); ///< 图片上传完成后设为锁屏壁纸 / Select an uploaded image as lock wallpaper
} read_pico_transfer_cfg_t;

typedef struct {
    read_pico_transfer_state_t state; ///< 当前状态 / Current state
    read_pico_transfer_mode_t mode; ///< 网络模式 / Network mode
    char url[64]; ///< 可访问地址，未联网为空 / Reachable address, empty when offline
    char wifi_ssid[33]; ///< 已保存网络名称，不含密码 / Saved network name, never a password
    bool wifi_configured; ///< 存在有效凭据 / Valid credentials saved
    bool network_ready; ///< 已取得可用网络地址 / Usable network address acquired
    unsigned sta_count; ///< 连接数 / Station count
    char ssid[33]; ///< 热点名称 / AP name
    char cur_name[241]; ///< 完整 UTF-8 文件名 / Complete UTF-8 filename
    size_t cur_bytes; ///< 已接收字节 / Received bytes
    size_t cur_total; ///< 本次总字节 / Request total bytes
    unsigned done_count; ///< 成功提交数 / Successfully committed files
    unsigned changed_count; ///< 提交、删除或进度清理重试成功的次数 / Commits, deletions, or successful progress-cleanup retries
    esp_err_t last_error; ///< 最近错误 / Last error
} read_pico_transfer_status_t;

/// 同一控制任务串行启动/停止；重复启动返回状态错误。/ Serialize start/stop on one owner task; repeated start fails.
esp_err_t read_pico_transfer_start(const read_pico_transfer_cfg_t *cfg);
/// 等待请求退出并释放本组件资源；可重复调用。/ Join requests and release owned resources; repeatable.
void read_pico_transfer_stop(void);
/// 原子拒绝文件操作期间的停止；成功则已停服，由同一控制任务调用。/ Atomically refuse stopping during file operations; true means stopped. Owner task only.
bool read_pico_transfer_try_stop_if_idle(void);
/// 锁屏浅睡前停用射频；唤醒后按原会话配置恢复。上传中返回 false。
bool read_pico_transfer_pause_for_sleep(void);
void read_pico_transfer_resume_after_sleep(void);
/// 跨任务复制一致状态快照。/ Copy a consistent snapshot across tasks.
void read_pico_transfer_get_status(read_pico_transfer_status_t *out);
/// 控制任务每500ms驱动有界连接重试；可见候选按信号轮换，总计不超过五次/30秒。/ Owner task polls every 500 ms; rotate visible candidates within five attempts and 30 seconds total.
void read_pico_transfer_service_poll(void);
/// 只读已保存SSID；未配置仍返回ESP_OK。/ Read only the saved SSID; unconfigured still returns ESP_OK.
esp_err_t read_pico_transfer_get_saved_wifi(char ssid[33], bool *configured);
typedef struct {
    uint8_t configured; ///< 是否已配网 / Whether STA credentials are configured
    char ssid[33]; ///< 已保存的网络名称 / Saved network name
    char password[65]; ///< 明文密码，调用者使用后必须清零 / Plaintext secret; caller must erase after use
} read_pico_transfer_wifi_backup_t;
/// 用户主动备份到TF卡时仅导出当前网络；明文凭据由调用者清零。
/// Export only the selected network for user-requested TF backup; caller must erase the plaintext.
esp_err_t read_pico_transfer_export_wifi_backup(read_pico_transfer_wifi_backup_t *out);
/// 恢复前校验凭据格式；不读写设备。/ Validate a backup record without accessing the device.
bool read_pico_transfer_wifi_backup_valid(const read_pico_transfer_wifi_backup_t *backup);
/// 恢复当前网络并保留其他已记住的网络；空记录清空历史，活动会话下次启动采用新配置。
/// Restore the selected network while retaining peers; an empty record clears history. Active sessions adopt it on their next startup.
esp_err_t read_pico_transfer_import_wifi_backup(const read_pico_transfer_wifi_backup_t *backup);
/// 仅热点或停止状态可遗忘；上传中拒绝。/ Forget only while AP or stopped; rejected during upload.
esp_err_t read_pico_transfer_forget_wifi(void);
/// 停服后同步扫描2.4GHz网络；最多16个去重SSID，按信号降序，临时射频和STA接口均释放。/ Scan synchronously while stopped; up to 16 unique SSIDs by descending RSSI; release temporary radio and STA resources.
esp_err_t read_pico_transfer_scan_wifi(read_pico_transfer_network_t out[READ_PICO_TRANSFER_SCAN_MAX], size_t *count);
/// 停服后保存设备输入的凭据，不自动连接；密码校验与网页相同。/ Save device-entered credentials while stopped without connecting; validation matches the webpage.
esp_err_t read_pico_transfer_save_wifi(const char *ssid, const char *password);
/// 选择记住的网络，无需把密码交给UI；停服时使用。/ Select a remembered network without exposing its password to the UI; service must be stopped.
esp_err_t read_pico_transfer_select_saved_wifi(const char *ssid);
/// 已连接 STA 时复用网络；停服时临时联网。成功返回 UTC 秒，保留原本在线状态。
/// Reuse a connected STA or connect briefly while stopped; return UTC seconds and preserve the prior online state.
esp_err_t read_pico_transfer_sync_time(uint32_t *utc_seconds);
/// 已连接 STA 时对时，不断开 WiFi；供 HTTPS 页面校验证书。/ Sync time on connected STA without disconnecting WiFi for HTTPS certificate checks.
esp_err_t read_pico_transfer_sync_time_online(uint32_t *utc_seconds);
