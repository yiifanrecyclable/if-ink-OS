/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 基于 MindReset Read Pico 官方 E0470 波形与刷新路径实现。
 * Built on the MindReset Read Pico E0470 waveform and refresh path.
 * 错相揭页引擎实现。16 带、每像素一次完整 GL16；差分只算一次，每拍只换对应相位的 1K LUT。
 * Staggered page-turn engine: 16 bands, one full GL16 transition per changed pixel,
 * one difference calculation, and a per-band 1 KiB phase LUT on each tick.
 */

#include "e0470_page_turn.h"

#include <stdbool.h>
#include <string.h>

#include "e0470_epaper_waveform.h"
#include "esp_attr.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_rom_sys.h"
#include "esp_timer.h"

static const char* TAG = "e0470_turn";

#define TURN_BANDS 16
#define TURN_PHASE_CAP 40
#define TURN_LINE_MAX 2048

static uint8_t (*s_lut)[1024];
static const uint8_t* s_lut_ptr[TURN_PHASE_CAP];
static int s_band0[TURN_BANDS];
static int s_band1[TURN_BANDS];
static int8_t s_band_phase[TURN_BANDS];
static int8_t s_line_phase[TURN_LINE_MAX] DRAM_ATTR;
static const EpdWaveformPhases* s_lut_src;
static int s_lut_n;
static int s_tick_us = E0470_TURN_DEFAULT_TICK_US;

void e0470_page_turn_release(void) {
    heap_caps_free(s_lut);
    s_lut = NULL;
    s_lut_src = NULL;
    s_lut_n = 0;
}

const char* e0470_turn_dir_name(e0470_turn_dir_t dir) {
    switch (dir) {
        case E0470_TURN_LTR: return "ltr";
        case E0470_TURN_RTL: return "rtl";
        case E0470_TURN_TTB: return "ttb";
        case E0470_TURN_BTT: return "btt";
        default: return "?";
    }
}

void e0470_page_turn_set_tick_us(int us) {
    if (us < 0) us = 0;
    s_tick_us = us;
}

int e0470_page_turn_tick_us(void) {
    return s_tick_us;
}

static void clip_rect(EpdRect* r, int w, int h) {
    if (r->x < 0) {
        r->width += r->x;
        r->x = 0;
    }
    if (r->y < 0) {
        r->height += r->y;
        r->y = 0;
    }
    if (r->x + r->width > w) r->width = w - r->x;
    if (r->y + r->height > h) r->height = h - r->y;
}

static EpdRect rotate_to_fb(EpdRect rect) {
    const int pw = epd_width();
    const int ph = epd_height();
    const int lx0 = rect.x;
    const int ly0 = rect.y;
    const int lx1 = rect.x + rect.width - 1;
    const int ly1 = rect.y + rect.height - 1;
    int ax, ay, bx, by;

    switch (epd_get_rotation()) {
        case EPD_ROT_LANDSCAPE:
            ax = lx0;
            ay = ly0;
            bx = lx1;
            by = ly1;
            break;
        case EPD_ROT_PORTRAIT:
            ax = pw - ly0 - 1;
            ay = lx0;
            bx = pw - ly1 - 1;
            by = lx1;
            break;
        case EPD_ROT_INVERTED_LANDSCAPE:
            ax = pw - lx0 - 1;
            ay = ph - ly0 - 1;
            bx = pw - lx1 - 1;
            by = ph - ly1 - 1;
            break;
        default:
            ax = ly0;
            ay = ph - lx0 - 1;
            bx = ly1;
            by = ph - lx1 - 1;
            break;
    }

    const int x0 = ax < bx ? ax : bx;
    const int x1 = ax < bx ? bx : ax;
    const int y0 = ay < by ? ay : by;
    const int y1 = ay < by ? by : ay;
    return (EpdRect){ .x = x0, .y = y0, .width = x1 - x0 + 1, .height = y1 - y0 + 1 };
}

static void phys_to_logical(int px, int py, int* lx, int* ly) {
    const int pw = epd_width();
    const int ph = epd_height();
    switch (epd_get_rotation()) {
        case EPD_ROT_LANDSCAPE:
            *lx = px;
            *ly = py;
            break;
        case EPD_ROT_PORTRAIT:
            *lx = py;
            *ly = pw - px - 1;
            break;
        case EPD_ROT_INVERTED_LANDSCAPE:
            *lx = pw - px - 1;
            *ly = ph - py - 1;
            break;
        default:
            *lx = ph - py - 1;
            *ly = px;
            break;
    }
}

static bool dir_is_lr(e0470_turn_dir_t dir) {
    return dir == E0470_TURN_LTR || dir == E0470_TURN_RTL;
}

static bool dir_is_reverse(e0470_turn_dir_t dir) {
    return dir == E0470_TURN_RTL || dir == E0470_TURN_BTT;
}

// 错相轴若落在物理 y 上，整行共用一个相位；落在物理 x 上则一行内分段。
// If the stagger axis is physical y, a whole line shares one phase; physical x needs column bands.
static bool uses_line_phase(e0470_turn_dir_t dir) {
    const bool lr = dir_is_lr(dir);
    switch (epd_get_rotation()) {
        case EPD_ROT_LANDSCAPE:
        case EPD_ROT_INVERTED_LANDSCAPE:
            return !lr;
        default:
            return lr;
    }
}

static int band_of(int coord, int origin, int span, int bands, bool reverse) {
    int band = (coord - origin) * bands / span;
    if (band < 0) band = 0;
    if (band >= bands) band = bands - 1;
    return reverse ? bands - 1 - band : band;
}

static void clear_bands(int* b0, int* b1, int n) {
    for (int i = 0; i < n; i++) {
        b0[i] = 0;
        b1[i] = 0;
    }
}

static void assign_bands(
    int* b0,
    int* b1,
    int bands,
    int from,
    int to,
    int step,
    bool along_x,
    int origin,
    int span,
    bool lr,
    bool reverse
) {
    clear_bands(b0, b1, bands);
    int cur = -1;
    int run = from;
    for (int p = from; p < to; p += step) {
        int lx, ly;
        if (along_x) phys_to_logical(p, 0, &lx, &ly);
        else phys_to_logical(0, p, &lx, &ly);
        const int coord = lr ? lx : ly;
        const int band = band_of(coord, origin, span, bands, reverse);
        if (band != cur) {
            if (cur >= 0) {
                b0[cur] = run;
                b1[cur] = p;
            }
            cur = band;
            run = p;
        }
    }
    if (cur >= 0) {
        b0[cur] = run;
        b1[cur] = to;
    }
}

static bool build_luts(const EpdWaveformPhases* gl) {
    // 37 KiB 相位表按需放入 PSRAM；避免长期占用 WiFi 和 USB 需要的内部内存。
    // Allocate the 37 KiB phase table in PSRAM on demand, preserving internal RAM for WiFi and USB.
    if (!s_lut) {
        s_lut = heap_caps_aligned_alloc(16, sizeof(uint8_t[TURN_PHASE_CAP][1024]),
                                        MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
        if (!s_lut) return false;
    }
    if (s_lut_src == gl && s_lut_n == gl->phases) return true;
    const int n = gl->phases < TURN_PHASE_CAP ? gl->phases : TURN_PHASE_CAP;
    for (int phase = 0; phase < n; phase++) {
        epd_build_1ppB_lut_1k(s_lut[phase], gl, phase);
        s_lut_ptr[phase] = s_lut[phase];
    }
    s_lut_src = gl;
    s_lut_n = gl->phases;
    return true;
}

static void copy_front_to_back(EpdiyHighlevelState* hl, EpdRect phys) {
    const int w = epd_width();
    const int h = epd_height();
    clip_rect(&phys, w, h);
    if (phys.width <= 0 || phys.height <= 0) return;

    for (int y = phys.y; y < phys.y + phys.height; y++) {
        uint8_t* src = hl->front_fb + y * w / 2;
        uint8_t* dst = hl->back_fb + y * w / 2;
        int x = phys.x;
        int x_last = phys.x + phys.width - 1;
        if (x & 1) {
            dst[x / 2] = (uint8_t)((src[x / 2] & 0xF0) | (dst[x / 2] & 0x0F));
            x++;
        }
        if ((x_last & 1) == 0) {
            dst[x_last / 2] = (uint8_t)((src[x_last / 2] & 0x0F) | (dst[x_last / 2] & 0xF0));
            x_last--;
        }
        if (x_last >= x) memcpy(dst + x / 2, src + x / 2, (size_t)((x_last - x + 1) / 2));
    }
}

enum EpdDrawError e0470_page_turn_with_waveform(EpdiyHighlevelState* hl, EpdRect area, e0470_turn_dir_t dir, const EpdWaveform *waveform) {
    if (hl == NULL) return EPD_DRAW_NO_PHASES_AVAILABLE;
    if (dir > E0470_TURN_BTT) dir = E0470_TURN_RTL;

    const EpdWaveformPhases* gl = e0470_waveform_phases(waveform, MODE_GL16);
    if (gl == NULL || gl->luts == NULL || gl->phases <= 0 || gl->phases > TURN_PHASE_CAP) {
        return EPD_DRAW_NO_PHASES_AVAILABLE;
    }

    const int bands = TURN_BANDS;
    const int nphase = gl->phases;
    const int ticks = bands + nphase - 1;
    const int fb_w = epd_width();
    const int fb_h = epd_height();
    if (fb_h > TURN_LINE_MAX) return EPD_DRAW_INVALID_CROP;

    EpdRect phys = rotate_to_fb(area);
    clip_rect(&phys, fb_w, fb_h);
    if (phys.width <= 0 || phys.height <= 0) return EPD_DRAW_SUCCESS;

    const int y0 = phys.y;
    const int y1 = phys.y + phys.height;
    const bool lr = dir_is_lr(dir);
    const bool reverse = dir_is_reverse(dir);
    const bool line_ph = uses_line_phase(dir);
    const int origin = lr ? area.x : area.y;
    const int span = lr ? (area.width > 0 ? area.width : 1) : (area.height > 0 ? area.height : 1);

    if (line_ph) {
        assign_bands(
            s_band0, s_band1, bands, y0, y1, 1, false, origin, span, lr, reverse
        );
    } else {
        const int x_lo = (phys.x + 15) & ~15;
        const int x_hi = (phys.x + phys.width) & ~15;
        assign_bands(
            s_band0, s_band1, bands, x_lo, x_hi, 16, true, origin, span, lr, reverse
        );
    }
    int assigned = 0;
    for (int band = 0; band < bands; ++band) assigned += s_band0[band] < s_band1[band];
    if (assigned != bands) return EPD_DRAW_INVALID_CROP;

    if (!build_luts(gl)) return EPD_DRAW_NO_PHASES_AVAILABLE;
    epd_poweron();

    const int64_t t_all = esp_timer_get_time();
    const int64_t t_gen = esp_timer_get_time();
    epd_difference_image_cropped(
        hl->front_fb, hl->back_fb, phys, hl->difference_fb, hl->dirty_lines, hl->dirty_columns
    );
    const int64_t gen_us = esp_timer_get_time() - t_gen;

    int64_t draw_us = 0;
    enum EpdDrawError err = EPD_DRAW_SUCCESS;
    for (int tick = 0; tick < ticks; tick++) {
        const int64_t t_tick = esp_timer_get_time();
        memset(hl->dirty_lines, 0, sizeof(bool) * (size_t)fb_h);
        memset(hl->dirty_columns, 0, (size_t)fb_w / 2);
        memset(s_band_phase, -1, (size_t)bands);
        if (line_ph) memset(s_line_phase, -1, (size_t)fb_h);

        bool any = false;
        for (int band = 0; band < bands; band++) {
            const int phase = tick - band;
            if (phase < 0 || phase >= nphase) continue;
            const int a = s_band0[band];
            const int b = s_band1[band];
            if (a >= b) continue;
            s_band_phase[band] = (int8_t)phase;
            if (line_ph) {
                memset(hl->dirty_lines + a, 1, (size_t)(b - a));
                memset(s_line_phase + a, (int)(int8_t)phase, (size_t)(b - a));
            } else {
                memset(hl->dirty_columns + a / 2, 0xFF, (size_t)((b - a) / 2));
            }
            any = true;
        }
        if (!any) continue;

        if (line_ph) {
            int xs = phys.x & ~1;
            int xe = (phys.x + phys.width + 1) & ~1;
            if (xe > xs) {
                memset(hl->dirty_columns + xs / 2, 0xFF, (size_t)((xe - xs) / 2));
            }
            epd_set_line_phase_luts(s_lut_ptr, s_line_phase);
        } else {
            memset(hl->dirty_lines + y0, 1, (size_t)(y1 - y0));
            epd_set_col_phase_luts(s_lut_ptr, s_band0, s_band1, s_band_phase, bands);
        }

        const int64_t t_draw = esp_timer_get_time();
        err = epd_draw_base(
            epd_full_screen(),
            hl->difference_fb,
            epd_full_screen(),
            MODE_PACKING_1PPB_DIFFERENCE | MODE_DU,
            25,
            hl->dirty_lines,
            hl->dirty_columns,
            &E0470_APPLY_WAVEFORM
        );
        epd_clear_phase_luts();
        draw_us += esp_timer_get_time() - t_draw;
        if (err != EPD_DRAW_SUCCESS) break;
        const int64_t used = esp_timer_get_time() - t_tick;
        if (s_tick_us > 0 && used < s_tick_us) {
            esp_rom_delay_us((uint32_t)(s_tick_us - used));
        }
    }

    // 扫描失败时屏幕可能停在中间相位，保留旧帧基准给调用方恢复。
    // A failed scan may leave intermediate pixels; keep the old baseline for caller recovery.
    if (err == EPD_DRAW_SUCCESS) copy_front_to_back(hl, phys);
    ESP_LOGI(
        TAG,
        "dir=%s ticks=%d gen=%d ms draw=%d ms scan_avg=%d us wall=%d ms err=%d",
        e0470_turn_dir_name(dir),
        ticks,
        (int)(gen_us / 1000),
        (int)(draw_us / 1000),
        ticks ? (int)(draw_us / ticks) : 0,
        (int)((esp_timer_get_time() - t_all) / 1000),
        (int)err
    );
    return err;
}

enum EpdDrawError e0470_page_turn(EpdiyHighlevelState *hl,EpdRect area,e0470_turn_dir_t dir){
    return e0470_page_turn_with_waveform(hl,area,dir,&E0470_WAVEFORM);
}

static enum EpdDrawError update_regions(EpdiyHighlevelState* hl, EpdRect area,
    EpdRect strong_area, EpdRect navigation, const EpdWaveform* soft_waveform,
    const EpdWaveform* strong_waveform, enum EpdDrawMode strong_mode) {
    const int w = epd_width(), h = epd_height();
    if (!hl || !hl->front_fb || !hl->back_fb || !hl->difference_fb ||
        !hl->dirty_lines || !hl->dirty_columns) return EPD_DRAW_NO_PHASES_AVAILABLE;
    if (epd_get_rotation() != EPD_ROT_INVERTED_PORTRAIT || area.x || area.width != h ||
        area.y < 0 || area.height <= 0 || area.y > w || area.height > w - area.y ||
        (area.y & 31) || (area.height & 31) || strong_area.x || strong_area.width != h ||
        strong_area.y < area.y || strong_area.height <= 0 || strong_area.y > area.y + area.height ||
        strong_area.height > area.y + area.height - strong_area.y ||
        (strong_area.y & 31) || (strong_area.height & 31)) return EPD_DRAW_INVALID_CROP;
    const bool has_navigation = navigation.height > 0;
    // 底栏只需16像素列对齐，正好覆盖1136..1216，不扩大到正文。/ A 16-pixel column boundary covers1136..1216 exactly without touching body pixels.
    if (has_navigation && (navigation.x || navigation.width != h ||
        navigation.y < area.y || navigation.y > area.y + area.height ||
        navigation.height != area.y + area.height - navigation.y ||
        (navigation.y & 15) || (navigation.height & 15))) return EPD_DRAW_INVALID_CROP;
    if (strong_mode != MODE_GL16 && strong_mode != MODE_GC16) return EPD_DRAW_NO_PHASES_AVAILABLE;
    const EpdWaveformPhases* soft = e0470_waveform_phases(soft_waveform, MODE_GL16);
    const EpdWaveformPhases* strong = e0470_waveform_phases(strong_waveform, strong_mode);
    if (!soft || !strong || !soft->luts || !strong->luts ||
        soft->phases <= 0 || strong->phases <= 0 || soft->phases > TURN_PHASE_CAP ||
        strong->phases > TURN_PHASE_CAP || soft->phase_times || strong->phase_times)
        return EPD_DRAW_NO_PHASES_AVAILABLE;
    const EpdWaveformPhases* nav = has_navigation ? e0470_waveform_phases(&E0470_WAVEFORM, MODE_GL16) : NULL;
    if (has_navigation && (!nav || !nav->luts || nav->phases <= 0 ||
        nav->phases > TURN_PHASE_CAP || nav->phase_times)) return EPD_DRAW_NO_PHASES_AVAILABLE;
    // 仅底栏发生真实变化时重建灰底；同页重绘/滚动不重复驱动它。/ Recalibrate navigation only when its actual pixels change; same-page repaint/scroll leaves it undriven.
    bool nav_changed = false;
    if (has_navigation) {
        EpdRect crop = rotate_to_fb(navigation);
        for (int y = crop.y; y < crop.y + crop.height && !nav_changed; ++y) {
            size_t offset = ((size_t)y * w + crop.x) / 2;
            nav_changed = memcmp(hl->front_fb + offset, hl->back_fb + offset, (size_t)crop.width / 2) != 0;
        }
    }
    // 每相最多三张1K表，正文、插图、底栏同一轮扫描；不缓存整屏或追加补刷。/ At most three1KiB LUTs share each scan phase; no full-frame cache or serial footer pass.
    uint8_t (*luts)[1024] = heap_caps_aligned_alloc(16, has_navigation ? 3072 : 2048, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!luts) return EPD_DRAW_NO_PHASES_AVAILABLE;
    const uint8_t* lut_ptrs[] = {luts[0], luts[1], has_navigation ? luts[2] : NULL};
    int bounds[] = {area.y, strong_area.y, strong_area.y + strong_area.height, area.y + area.height,
                    navigation.y, navigation.y + navigation.height};
    int count = has_navigation ? 6 : 4;
    for (int i = 1; i < count; ++i) {
        int edge = bounds[i], j = i;
        while (j > 0 && bounds[j - 1] > edge) { bounds[j] = bounds[j - 1]; --j; }
        bounds[j] = edge;
    }
    int starts[5], ends[5]; int8_t selected[5]; int bands = 0;
    for (int i = 0; i < count - 1; ++i) {
        if (bounds[i] == bounds[i + 1]) continue;
        starts[bands] = bounds[i]; ends[bands] = bounds[i + 1];
        selected[bands] = has_navigation && bounds[i] >= navigation.y ? (nav_changed ? 2 : -1) :
            bounds[i] >= strong_area.y && bounds[i] < strong_area.y + strong_area.height ? 1 : 0;
        ++bands;
    }
    const EpdRect phys = rotate_to_fb(area);
    epd_difference_image_cropped(hl->front_fb, hl->back_fb, phys, hl->difference_fb,
                                  hl->dirty_lines, hl->dirty_columns);
    // 校准区包含等灰像素；外侧等灰是否保持由原柔和表决定，不伪造前一帧。
    // Include equal grays for art calibration; the original soft table holds equal chrome without falsifying the prior frame.
    memset(hl->dirty_lines, 1, (size_t)h * sizeof(bool));
    memset(hl->dirty_columns, 0, (size_t)w / 2);
    memset(hl->dirty_columns + area.y / 2, 0xff, (size_t)area.height / 2);
    int phases = soft->phases > strong->phases ? soft->phases : strong->phases;
    if (nav && nav->phases > phases) phases = nav->phases;
    epd_poweron();
    enum EpdDrawError error = EPD_DRAW_SUCCESS;
    for (int phase = 0; phase < phases; ++phase) {
        if (phase < soft->phases) epd_build_1ppB_lut_1k(luts[0], soft, phase);
        else memset(luts[0], 0, 1024);
        if (phase < strong->phases) epd_build_1ppB_lut_1k(luts[1], strong, phase);
        else memset(luts[1], 0, 1024);
        if (has_navigation) {
            if (nav_changed && phase < nav->phases) epd_build_1ppB_lut_1k(luts[2], nav, phase);
            else memset(luts[2], 0, 1024);
        }
        epd_set_col_phase_luts(lut_ptrs, starts, ends, selected, bands);
        error = epd_draw_base(epd_full_screen(), hl->difference_fb, epd_full_screen(),
            MODE_PACKING_1PPB_DIFFERENCE | MODE_DU, 25,
            hl->dirty_lines, hl->dirty_columns, &E0470_APPLY_WAVEFORM);
        epd_clear_phase_luts();
        if (error != EPD_DRAW_SUCCESS) break;
    }
    heap_caps_free(luts);
    if (error == EPD_DRAW_SUCCESS) copy_front_to_back(hl, phys);
    return error;
}

// 保持既有分区调用与阅读水波纹路径独立。/ Keep existing region callers independent of reader ripple.
enum EpdDrawError e0470_update_regions(EpdiyHighlevelState* hl, EpdRect area, EpdRect art,
    const EpdWaveform* soft, const EpdWaveform* strong, enum EpdDrawMode mode) {
    return update_regions(hl, area, art, (EpdRect){0}, soft, strong, mode);
}

enum EpdDrawError e0470_update_navigation_regions(EpdiyHighlevelState* hl, EpdRect area,
    EpdRect art, EpdRect navigation, const EpdWaveform* soft, const EpdWaveform* strong) {
    if (navigation.height <= 0) return EPD_DRAW_INVALID_CROP;
    return update_regions(hl, area, art, navigation, soft, strong, MODE_GL16);
}
