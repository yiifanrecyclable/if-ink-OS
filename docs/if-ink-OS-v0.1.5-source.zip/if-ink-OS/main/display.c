/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 刷屏出口：按模式推屏、HV 轨空闲下电、pclk 欠载回退。
 *
 * Present path: push by mode, drop HV rails on idle, fall back pclk on
 * underrun.
 */

#include "display.h"
#include "display_profiles.h"

#include <stdbool.h>
#include <stdint.h>

#include "app_config.h"
#include "e0470_epaper_waveform.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "read_pico_board.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"

// 刷屏、驱动释放和空闲断电共享递归锁，复合输出在最后才交还。/ Serialize scans, drive release and idle poweroff across composite outputs.
static StaticSemaphore_t s_output_lock_storage;
static SemaphoreHandle_t s_output_lock;
static portMUX_TYPE s_output_init = portMUX_INITIALIZER_UNLOCKED;
static SemaphoreHandle_t display_guard_begin(void) {
    portENTER_CRITICAL(&s_output_init);
    if (!s_output_lock) s_output_lock=xSemaphoreCreateRecursiveMutexStatic(&s_output_lock_storage);
    portEXIT_CRITICAL(&s_output_init);
    xSemaphoreTakeRecursive(s_output_lock,portMAX_DELAY);
    return s_output_lock;
}
static void display_guard_end(SemaphoreHandle_t *lock) { xSemaphoreGiveRecursive(*lock); }
#define DISPLAY_GUARD SemaphoreHandle_t output_guard __attribute__((cleanup(display_guard_end)))=display_guard_begin()

static const char* TAG = "read_pico";
static bool s_bulk_io;
static int s_pclk_mhz = DISPLAY_PCLK_DEFAULT_MHZ;

void display_set_bulk_io(bool active) {
    DISPLAY_GUARD;
    s_bulk_io = active;
    ESP_LOGI(TAG, "bulk I/O scan margin %s", active ? "on" : "off");
}

// HV 轨道空闲多久才断电。断电要等 500ms 放电，再上电又要几十毫秒，
// 所以连续操作期间一直保持常开，只有真的没人动才关掉省电并卸掉 VCOM。
// How long HV rails stay up when idle. Power-off waits 500 ms to discharge,
// and power-on takes tens of ms, so keep them on during a burst of work and
// drop them — and VCOM — only when nothing is happening.
#define RAILS_IDLE_TIMEOUT_MS 8000

// 0 表示轨道已断电；否则是到期时间（ms），到点后主循环断电。
// 0 means the rails are off; otherwise a deadline (ms) after which the loop powers them down.
static int64_t rails_deadline_ms;
static int64_t drive_release_retry_ms;

void display_poweroff(void) {
    DISPLAY_GUARD;
    for(unsigned attempt=0;attempt<3;++attempt){
        if(read_pico_epd_release_drive())break;
        if(attempt<2)vTaskDelay(pdMS_TO_TICKS(5));
    }
    rails_deadline_ms=drive_release_retry_ms=0;
    epd_poweroff();
}

void rails_keepalive(void) {
    DISPLAY_GUARD;
    drive_release_retry_ms = read_pico_epd_release_drive() ? 0 : esp_timer_get_time()/1000+50;
    rails_deadline_ms = esp_timer_get_time() / 1000 + RAILS_IDLE_TIMEOUT_MS;
}

void rails_idle_check(int64_t now_ms) {
    DISPLAY_GUARD;
    if(drive_release_retry_ms && now_ms>=drive_release_retry_ms)
        drive_release_retry_ms=read_pico_epd_release_drive()?0:now_ms+50;
    if (rails_deadline_ms != 0 && now_ms >= rails_deadline_ms) {
        rails_deadline_ms = 0;
        drive_release_retry_ms = 0;
        display_poweroff();
    }
}

// 20 相完整/原厂 DU 按厂家时序走 FULL；只有触摸笔迹用的 8 帧跟随 DU 走 FAST。
// 20-phase full / vendor DU uses FULL timing; the 8-frame FOLLOW DU used for ink trails uses FAST.
static void use_scan_for(const EpdWaveform* waveform, enum EpdDrawMode mode) {
    const bool fast = (mode & 0xF) == MODE_DU && waveform == &E0470_FOLLOW_WAVEFORM;
    read_pico_epd_use_scan(fast ? READ_PICO_EPD_SCAN_FAST : READ_PICO_EPD_SCAN_FULL);
    // 高层刷新保持整屏扫描；两条63行可用队列在第127行入队前启动。
    // High-level updates scan the full panel; two 63-slot queues start before line 127 is enqueued.
    epd_lcd_set_prefill_lines(s_bulk_io ? 127 : (fast ? 64 : 32));
}

// 自上次整屏 GC16 以来的整页差分次数。局部反馈不计数，否则菜单按压几次就会触发黑白全刷。
// Whole-page differentials since the last full GC16. Local feedback is excluded so a few taps cannot trigger flashing.
static int s_page_refreshes;

// 所有按 fb 刷屏的出口都经这里。GL16 必须全像素（白底补 1 帧靠它打到）。
// 整页差分刷攒够 APP_UI_GC16_EVERY 次就把这一次升为全像素 GC16：区域、fb 都不变，只换模式，
// 屏上内容仍由 fb 决定，不会丢；全像素是为了让未变化像素也过一遍 LUT，否则压不掉灰底。
// 跟随 DU 波形只有 DU 一张表，不计数也不升级。
// Every fb present goes through here. GL16 must be full-pixel (the extra white
// frame depends on that). After APP_UI_GC16_EVERY whole-page updates, this one is
// promoted to full-pixel GC16: area and fb stay the same, only the mode
// changes, so content is not lost. Full-pixel is so unchanged pixels also run
// the LUT; otherwise the gray floor will not clear. FOLLOW DU has only a DU
// table and does not count or promote.
static enum EpdDrawError hl_update(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode, bool full,
    const EpdRect* area, bool allow_gl16_diff
) {
    full = full || ((mode & 0xF) == MODE_GL16 && !allow_gl16_diff);
    if (waveform != &E0470_FOLLOW_WAVEFORM && area == NULL) {
        if ((mode & 0xF) == MODE_GC16) {
            s_page_refreshes = 0;
        } else if (APP_UI_GC16_EVERY > 0 && ++s_page_refreshes >= APP_UI_GC16_EVERY) {
            s_page_refreshes = 0;
            mode = (enum EpdDrawMode)((mode & ~0xF) | MODE_GC16);
            full = true;
            ESP_LOGI(TAG, "promote to GC16 after %d page transitions", APP_UI_GC16_EVERY);
        }
    }
    if (area != NULL) {
        return full ? epd_hl_update_area_full(hl, mode, 25, *area)
                    : epd_hl_update_area(hl, mode, 25, *area);
    }
    return full ? epd_hl_update_screen_full(hl, mode, 25) : epd_hl_update_screen(hl, mode, 25);
}

enum EpdDrawError update_display_mode(
    EpdiyHighlevelState* hl, enum EpdDrawMode mode
) {
    DISPLAY_GUARD;
    use_scan_for(&E0470_WAVEFORM, mode);
    epd_poweron();
    enum EpdDrawError result = hl_update(hl, &E0470_WAVEFORM, mode, false, NULL, false);
    rails_keepalive();
    return result;
}

enum EpdDrawError update_display_mode_diff(
    EpdiyHighlevelState* hl, enum EpdDrawMode mode
) {
    DISPLAY_GUARD;
    use_scan_for(&E0470_WAVEFORM, mode);
    epd_poweron();
    enum EpdDrawError result = hl_update(hl, &E0470_WAVEFORM, mode, false, NULL, true);
    rails_keepalive();
    return result;
}

enum EpdDrawError update_display_fast_page(EpdiyHighlevelState* hl) {
    DISPLAY_GUARD;
    if (APP_UI_FAST_GC16_EVERY > 0 && ++s_page_refreshes >= APP_UI_FAST_GC16_EVERY) {
        s_page_refreshes = 0;
        use_scan_for(&E0470_WAVEFORM, MODE_GC16);
        epd_poweron();
        enum EpdDrawError result = epd_hl_update_screen_full(hl, MODE_GC16, 25);
        rails_keepalive();
        ESP_LOGI(TAG, "fast navigation cleanup after %d transitions", APP_UI_FAST_GC16_EVERY);
        return result;
    }
    use_scan_for(&E0470_WAVEFORM, MODE_GL16);
    epd_poweron();
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    // 间隔性驱动未变化区域，减少跨页白底与细线累积残影，不插入第二次刷新。
    // Periodically drive unchanged areas to reduce old-page ghosts without a second repaint.
    const bool settle = APP_UI_FAST_GL16_SETTLE_EVERY > 0 &&
                        s_page_refreshes % APP_UI_FAST_GL16_SETTLE_EVERY == 0;
    enum EpdDrawError result = settle ? epd_hl_update_screen_full(hl, MODE_GL16, 25)
                                      : epd_hl_update_screen(hl, MODE_GL16, 25);
    rails_keepalive();
    return result;
}

enum EpdDrawError update_display_from_white_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode
) {
    DISPLAY_GUARD;
    use_scan_for(waveform, mode);
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    enum EpdDrawError result = epd_hl_update_screen_from_white(hl, mode, 25);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    s_page_refreshes = 0;
    rails_keepalive();
    return result;
}

enum EpdDrawError update_display_from_white(EpdiyHighlevelState* hl) {
    DISPLAY_GUARD;
    return update_display_from_white_with(hl, &E0470_WAVEFORM, MODE_GC16);
}

enum EpdDrawError update_display_white(EpdiyHighlevelState* hl) {
    DISPLAY_GUARD;
    epd_hl_set_all_white(hl);
    return update_display_full(hl);
}

static bool s_white_exit;

void display_hold_white_exit(bool hold) {
    DISPLAY_GUARD;
    s_white_exit = hold;
}

bool display_take_white_exit(void) {
    DISPLAY_GUARD;
    const bool hold = s_white_exit;
    s_white_exit = false;
    return hold;
}

enum EpdDrawError update_display_full(EpdiyHighlevelState* hl) {
    DISPLAY_GUARD;
    use_scan_for(&E0470_WAVEFORM, MODE_GC16);
    epd_poweron();
    enum EpdDrawError result = hl_update(hl, &E0470_WAVEFORM, MODE_GC16, true, NULL, false);
    rails_keepalive();
    return result;
}

enum EpdDrawError update_display_image_gray(EpdiyHighlevelState* hl) {
    DISPLAY_GUARD;
    // 图片保留十六级原始灰阶；白底和完整 48 相波形稳定呈现层次。
    // Images keep sixteen source grays; a white baseline and the full 48-phase table preserve tones.
    use_scan_for(&E0470_FULL_WAVEFORM, MODE_GC16);
    epd_poweron();
    epd_clear();
    epd_hl_waveform(hl, &E0470_FULL_WAVEFORM);
    enum EpdDrawError result = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    s_page_refreshes = 0;
    rails_keepalive();
    return result;
}

enum EpdDrawError update_display_home_clean(EpdiyHighlevelState* hl){
    DISPLAY_GUARD;
    use_scan_for(&E0470_FULL_WAVEFORM,MODE_GC16);
    epd_poweron();epd_hl_waveform(hl,&E0470_FULL_WAVEFORM);
    // 使用已知前帧，所有灰底像素都走完整波形，取消前置多轮擦白。/ Use the tracked prior frame and drive every gray pixel without a multi-pass white preclear.
    enum EpdDrawError result=hl_update(hl,&E0470_FULL_WAVEFORM,MODE_GC16,true,NULL,false);
    epd_hl_waveform(hl,&E0470_WAVEFORM);rails_keepalive();return result;
}

// 指定波形整屏刷一次，刷完把默认波形装回去。用来 A/B 两条灰阶表。
// Present the whole screen with a given waveform, then restore the default. Used to A/B two gray tables.
enum EpdDrawError update_display_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode
) {
    DISPLAY_GUARD;
    use_scan_for(waveform, mode);
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    enum EpdDrawError result = hl_update(hl, waveform, mode, false, NULL, false);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    rails_keepalive();
    return result;
}

enum EpdDrawError update_display_area_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
) {
    DISPLAY_GUARD;
    use_scan_for(waveform, mode);
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    enum EpdDrawError result = hl_update(hl, waveform, mode, false, &area, false);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    rails_keepalive();
    return result;
}

enum EpdDrawError update_display_area_diff_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
) {
    DISPLAY_GUARD;
    use_scan_for(waveform, mode);
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    enum EpdDrawError result = hl_update(hl, waveform, mode, false, &area, true);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    rails_keepalive();
    return result;
}

enum EpdDrawError update_display_area_full_with(
    EpdiyHighlevelState* hl, const EpdWaveform* waveform, enum EpdDrawMode mode,
    EpdRect area
) {
    DISPLAY_GUARD;
    use_scan_for(waveform, mode);
    epd_poweron();
    epd_hl_waveform(hl, waveform);
    enum EpdDrawError result = hl_update(hl, waveform, mode, true, &area, false);
    epd_hl_waveform(hl, &E0470_WAVEFORM);
    rails_keepalive();
    return result;
}

enum EpdDrawError update_display_water_turn(EpdiyHighlevelState* hl, EpdRect area,
                                             e0470_turn_dir_t dir) {
    DISPLAY_GUARD;
    // 只在阅读页显式调用；普通页面仍走原刷新路径。
    // Only the reader calls this path; ordinary pages keep their existing refresh policy.
    read_pico_epd_use_scan(READ_PICO_EPD_SCAN_FAST);
    epd_lcd_set_prefill_lines(s_bulk_io ? 127 : 64);
    epd_poweron();
    enum EpdDrawError result = e0470_page_turn_with_waveform(hl, area, dir, display_text_waveform());
    use_scan_for(&E0470_WAVEFORM, MODE_GL16);
    rails_keepalive();
    if (result == EPD_DRAW_SUCCESS) return result;
    if (result == EPD_DRAW_NO_PHASES_AVAILABLE) {
        ESP_LOGW(TAG, "water turn phases unavailable; use regular GL16");
        return update_display_area_with(hl, &E0470_WAVEFORM, MODE_GL16, area);
    }
    // 中断可能把物理屏留在半途。清屏后按目标 front 重建整屏基准。
    // An interrupted scan may leave intermediate pixels. Rebuild the whole baseline from white.
    if (result & EPD_DRAW_EMPTY_LINE_QUEUE) {
        s_pclk_mhz = DISPLAY_PCLK_SAFE_MHZ;
        read_pico_epd_set_pclk(DISPLAY_PCLK_SAFE_MHZ);
    }
    use_scan_for(&E0470_WAVEFORM, MODE_GC16);
    epd_clear();
    enum EpdDrawError recovered = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);
    s_page_refreshes = 0;
    rails_keepalive();
    ESP_LOGW(TAG, "water turn failed (%d), recovery=%d", result, recovered);
    return recovered;
}

// 供数不足时的兜底：把频率退回安全值，整屏白一次，让后面的差分刷有干净参考帧。
// Underrun fallback: drop to the safe clock and wipe the panel white so later differentials have a clean reference.
int display_pclk_mhz(void) { return s_pclk_mhz; }

void guard_draw_result(EpdiyHighlevelState* hl, enum EpdDrawError result) {
    DISPLAY_GUARD;
    if (!(result & EPD_DRAW_EMPTY_LINE_QUEUE)) return;
    s_pclk_mhz = DISPLAY_PCLK_SAFE_MHZ;
    read_pico_epd_set_pclk(DISPLAY_PCLK_SAFE_MHZ);
    use_scan_for(&E0470_WAVEFORM, MODE_GC16);
    epd_poweron();
    epd_clear();
    // 清物理屏后仅重置旧帧基准，保留目标页；否则局部刷新会留下整页白屏。
    // Reset only the old-frame baseline after clearing; preserving the target prevents blank pages after partial updates.
    epd_hl_update_screen_from_white(hl, MODE_GC16, 25);
    s_page_refreshes = 0;
    rails_keepalive();
    ESP_LOGW(TAG, "line queue underrun, pclk back to %d MHz", DISPLAY_PCLK_SAFE_MHZ);
}

enum EpdDrawError update_display_natural_page(EpdiyHighlevelState *hl,EpdRect art){
    DISPLAY_GUARD;
    if(APP_UI_FAST_GC16_EVERY>0 && ++s_page_refreshes>=APP_UI_FAST_GC16_EVERY)return update_display_full(hl);
    if(art.height<=0)art=(EpdRect){0,0,684,1216};
    use_scan_for(&E0470_WAVEFORM,MODE_GL16);
    epd_poweron();
    enum EpdDrawError err=e0470_update_regions(hl,(EpdRect){0,0,684,1216},art,
        display_natural_waveform(),art.y==0&&art.height==1216?display_natural_waveform():display_art_waveform(),MODE_GL16);
    if(err==EPD_DRAW_NO_PHASES_AVAILABLE){
        epd_hl_waveform(hl,&E0470_WAVEFORM);err=epd_hl_update_screen_full(hl,MODE_GL16,25);
    }else if(err!=EPD_DRAW_SUCCESS){
        // 中途失败不可对未知物理状态继续差分，恢复完整目标，含灰底导航。/ An interrupted scan needs a known baseline and a complete target, including navigation.
        epd_clear();epd_hl_waveform(hl,&E0470_FULL_WAVEFORM);
        err=epd_hl_update_screen_from_white(hl,MODE_GC16,25);
    }
    epd_hl_waveform(hl,&E0470_WAVEFORM);rails_keepalive();return err;
}

enum EpdDrawError update_display_navigation_page(EpdiyHighlevelState *hl,EpdRect art,EpdRect navigation){
    DISPLAY_GUARD;
    if(APP_UI_FAST_GC16_EVERY>0 && ++s_page_refreshes>=APP_UI_FAST_GC16_EVERY)return update_display_full(hl);
    bool no_art=art.height<=0;
    if(no_art)art=(EpdRect){0,0,684,1216};
    use_scan_for(&E0470_WAVEFORM,MODE_GL16);
    epd_poweron();
    enum EpdDrawError err=e0470_update_navigation_regions(hl,(EpdRect){0,0,684,1216},art,navigation,
        display_natural_waveform(),no_art?display_natural_waveform():display_art_waveform());
    if(err==EPD_DRAW_NO_PHASES_AVAILABLE){
        epd_hl_waveform(hl,&E0470_WAVEFORM);err=epd_hl_update_screen_full(hl,MODE_GL16,25);
    }else if(err!=EPD_DRAW_SUCCESS){
        // 不把半途光学状态当作参考帧；失败统一重建完整目标。/ Never treat an interrupted optical state as the baseline; rebuild the complete target after failure.
        if(err & EPD_DRAW_EMPTY_LINE_QUEUE){
            s_pclk_mhz=DISPLAY_PCLK_SAFE_MHZ;read_pico_epd_set_pclk(DISPLAY_PCLK_SAFE_MHZ);
        }
        epd_clear();epd_hl_waveform(hl,&E0470_FULL_WAVEFORM);
        err=epd_hl_update_screen_from_white(hl,MODE_GC16,25);
        s_page_refreshes=0;
    }
    epd_hl_waveform(hl,&E0470_WAVEFORM);rails_keepalive();return err;
}

enum EpdDrawError update_display_natural_area(EpdiyHighlevelState *hl,EpdRect area){
    DISPLAY_GUARD;
    return update_display_area_diff_with(hl,display_natural_waveform(),MODE_GL16,area);
}
