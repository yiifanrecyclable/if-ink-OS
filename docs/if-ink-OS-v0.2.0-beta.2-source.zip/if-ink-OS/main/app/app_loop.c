/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 事件循环。只做和页面无关的事：读触摸并去抖、三个实体键与菜单把手的路由、切页
 * 时调 on_exit/on_enter、按回调返回值决定怎么刷屏、电源键锁屏、SD 卡上的字体延迟
 * 加载。页面自己的状态和刷新节奏都在 main/apps/ 各自的文件里。
 *
 * Event loop for page-agnostic work: touch debounce, the three keys and
 * the menu handle, on_exit/on_enter, present, lock, delayed SD font load.
 * Page state and refresh cadence stay in main/apps/; gesture recognition is shared.
 * 用户修订：重新插卡时，在页面释放旧句柄及卡上字体后自动调用显式重挂；每次插入只尝试一次。
 * User revision: remount reinserted cards after closing page handles/card fonts, once per insertion.
 *
 * 冻结：主循环只产出手势、不解释含义；产品系统页接管三键，按用户要求
 * 左右返回、中键首页；阅读页保留翻页、页面设置和长按回书架。把手仍按下即触发。
 * 接管页可选长按键回调，保留按下行为；同键单指500ms仅触发一次，中断取消。
 * Frozen: Produce gestures without interpreting page actions. Product system pages
 * own Back/Home/Back keys; reading retains page turns, settings and hold-to-shelf.
 * Owners may opt into a single 500ms same-key hold callback after the press action; interruptions cancel it.
 * The menu handle still fires on press.
 * 用户修订：主导航采用同步普通灰阶刷新，取消系统页面波浪；唤醒首帧统一清除壁纸。
 * User revision: root transitions use simultaneous ordinary grayscale without main-page ripple; the first post-wake frame clears wallpaper.
 * 冻结：返回消费最近切页来源，恢复原页及菜单位置，不跳固定首页。
 * Frozen: Return consumes the latest page origin, restoring its page and menu position.
 */

#include "app_loop.h"

#include <string.h>
#include <time.h>
#include "battery_history.h"
#include "time_service.h"

#include "app_registry.h"
#include "app_content_open.h"
#include "continuous_du.h"
#include "display.h"
#include "e0470_epaper_waveform.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "read_pico_board.h"
#include "read_pico_pmu.h"
#include "read_pico_transfer.h"
#include "read_pico_sd.h"
#include "bundled_assets.h"
#include "settings.h"
#include "sleep.h"
#include "sleep_resume.h"
#include "ttf_font.h"
#include "app_font_context.h"
#include "ui_kit.h"
#include "ui_menu.h"
#include "ui_gesture.h"
#include "operation_log.h"
extern bool app_book_reader_body_visible(void);
#include "ui_power_dialog.h"
#include "usb_storage.h"

#define TAG "app_loop"

// 触摸芯片报点率远高于屏幕，主循环空转一轮只等这么久。
// Touch reports far faster than the panel; idle this long per loop.
#define LOOP_TICK_MS 5
// SD 卡插上或者刚挂好时，隔一会儿再试一次存在设置里的字体。
// Retry the saved SD font shortly after a card appears or mounts.
#define FONT_RETRY_INTERVAL_MS 750
#define MEDIA_POLL_INTERVAL_MS 500
// 每次重新插入只发起一次恢复；失败保留提示，不在主循环反复重挂。/ One recovery per insertion; keep failures visible instead of repeatedly remounting.
static bool s_media_recovery_requested;

static int64_t s_lock_ignore_until_ms;
extern const app_desc_t app_transfer;

void app_lock_ignore_for(int64_t ms) {
    s_lock_ignore_until_ms = esp_timer_get_time() / 1000 + ms;
}

void app_present(app_ctx_t* ctx, const app_desc_t* app, app_redraw_t redraw) {
    enum EpdDrawError result = EPD_DRAW_SUCCESS;
    // 唤醒必须先画完整目标；仍调用页面自己的present来完成阅读等状态收尾。
    // Draw a complete post-wake target while retaining each page's present-state bookkeeping.
    if(redraw!=APP_REDRAW_NONE && redraw!=APP_REDRAW_DONE && display_resume_clean_pending())redraw=APP_REDRAW_FULL;
    ui_text_set_system_scale(true);
    if (app->present != NULL && app->present(ctx, redraw)) return;
    switch (redraw) {
        case APP_REDRAW_NONE:
        case APP_REDRAW_DONE:
            return;
        case APP_REDRAW_AREA: {
            // 回调已经画好了 fb，这里只负责把它那一块推上屏。
            // The callback already painted fb; push that rectangle only.
            EpdRect area = app->area_hint != NULL
                ? app->area_hint(ctx)
                : ui_content_refresh_area();
            result = update_display_area_with(
                ctx->hl, &E0470_WAVEFORM, APP_DYNAMIC_REFRESH_MODE, area
            );
            break;
        }
        case APP_REDRAW_FULL:
            if (app->render != NULL) app->render(ctx, ctx->fb);
            result = APP_PAGE_FORCE_FULL
                ? update_display_full(ctx->hl)
                : update_display_mode(ctx->hl, APP_PAGE_REFRESH_MODE);
            break;
        case APP_REDRAW_PAGE:
        default:
            if (app->render != NULL) app->render(ctx, ctx->fb);
            result = update_display_fast_page(ctx->hl);
            break;
    }
    guard_draw_result(ctx->hl, result);
}

// 中断边界先清页面装饰再清识别器。/ Clear decoration before resetting recognition.
static void cancel_gesture(app_ctx_t* ctx, const app_desc_t* app, ui_gesture_t* gesture) {
    if (gesture->active && app->on_gesture) {
        ui_gesture_event_t event = { .type = UI_GESTURE_CANCEL,
            .x0 = gesture->x0, .y0 = gesture->y0, .x = gesture->x, .y = gesture->y };
        const app_desc_t* requested = ctx->request_app;
        bool menu_requested = ctx->request_menu;
        bool return_requested = ctx->request_return;
        operation_log_event(OPLOG_CANCEL,3,0,0,0,0);
        app_redraw_t redraw = app->on_gesture(ctx, &event);
        ctx->request_app = requested;
        ctx->request_menu = menu_requested;
        ctx->request_return = return_requested;
        ui_gesture_reset(gesture);
        app_present(ctx, app, redraw);
    }
    ui_gesture_reset(gesture);
}

static void present_page(app_ctx_t* ctx, const app_desc_t* app,
                         ui_gesture_t* gesture, app_redraw_t redraw) {
    if (redraw == APP_REDRAW_PAGE || redraw == APP_REDRAW_FULL) {
        operation_log_event(OPLOG_CANCEL,2,redraw,0,0,0);
        cancel_gesture(ctx, app, gesture);
    }
    app_present(ctx, app, redraw);
}

typedef struct {
    unsigned updates;
    int64_t last_ms;
    EpdRect area;
} menu_feedback_t;

// 菜单反馈只推叶内单行。/ Menu feedback pushes one local row only.
static void menu_feedback(app_ctx_t* ctx, const app_desc_t* current,
                          int leaf, int hit, bool pressed, menu_feedback_t* feedback) {
    EpdRect area;
    int row = hit - leaf * UI_MENU_ITEMS_PER_PAGE;
    if (!ui_menu_row_rect(leaf, row, &area)) return;
    ui_draw_menu_row_pressed(ctx->fb, current, leaf, row, pressed);
    if (feedback->updates == 0) feedback->area = area;
    else {
        int bottom = feedback->area.y + feedback->area.height;
        int next_bottom = area.y + area.height;
        if (area.y < feedback->area.y) feedback->area.y = area.y;
        feedback->area.height = (bottom > next_bottom ? bottom : next_bottom) - feedback->area.y;
    }
    feedback->updates++;
    feedback->last_ms = ctx->now_ms;
    guard_draw_result(ctx->hl, update_display_area_with(
        ctx->hl, &E0470_WAVEFORM, APP_DYNAMIC_REFRESH_MODE, area));
    if (feedback->updates >= UI_SETTLE_DU_MAX) {
        guard_draw_result(ctx->hl, update_display_area_with(
            ctx->hl, &E0470_WAVEFORM, MODE_GL16, feedback->area));
        feedback->updates = 0;
    }
}

// 切页：先让上一页收尾，再给新页一次 on_enter，最后整页画出来。
// Leave the old page, enter the new one, then present a full page.
static void switch_to(
    app_ctx_t* ctx, const app_desc_t** current, const app_desc_t* next
) {
    operation_log_event(OPLOG_PAGE,app_index_of(next),0,0,0,0);
    if (next == NULL || next == *current) return;
    if ((*current)->on_exit != NULL) (*current)->on_exit(ctx);
    *current = next;
    app_font_activate_system();
    if (next->on_enter != NULL) next->on_enter(ctx);
    app_present(ctx, next, next->enter_full ? APP_REDRAW_FULL : APP_REDRAW_PAGE);
    ESP_LOGI(TAG, "page -> %s", next->title);
}

// 菜单页不是 app，单独画。/ The menu is not an app; present it here.
static void present_menu(app_ctx_t* ctx, const app_desc_t* current, int leaf, menu_feedback_t* feedback) {
    feedback->updates = 0;
    if (display_take_white_exit()) {
        guard_draw_result(ctx->hl, update_display_white(ctx->hl));
    }
    ui_draw_menu_page(ctx->fb, current, leaf);
    guard_draw_result(ctx->hl, update_display_fast_page(ctx->hl));
}

// 空槽常带着抬起事件或残留坐标，不能进页面看到的快照；抬手后保留最后一次位置。
// Empty slots often carry lift events or stale coords; keep last position on lift.
static void debounce_touch(
    cst836u_touch_t* latest, const cst836u_touch_t* raw, bool released
) {
    if (raw->touched) {
        *latest = *raw;
        for (int i = 0; i < CST836U_MAX_POINTS; i++) {
            if (!latest->points[i].active) {
                memset(&latest->points[i], 0, sizeof(latest->points[i]));
            }
        }
    } else if (released) {
        latest->touched = false;
        latest->count = 0;
        for (int i = 0; i < CST836U_MAX_POINTS; i++) {
            latest->points[i].active = false;
        }
    }
    memcpy(latest->raw, raw->raw, sizeof(raw->raw));
}

static bool try_load_saved_sd_font(bool allow_probe) {
    read_pico_sd_info_t info;
    esp_err_t err = read_pico_sd_get_info(&info);
    if (err == ESP_ERR_NOT_FINISHED) return false;
    if (!info.mounted) {
        if (allow_probe && err == ESP_ERR_INVALID_STATE) read_pico_sd_start_probe();
        return false;
    }
    return app_font_retry_active();
}

// 先停文件使用者、关闭卡上字体；下一次观察到插卡才显式重挂。
// Stop consumers and close card fonts before explicitly remounting on a later insertion poll.
static bool poll_media(app_ctx_t* ctx, const app_desc_t* current,
                       bool* mounted, bool* invalidated) {
    if (usb_storage_active()) { *mounted = false; *invalidated = false; s_media_recovery_requested = false; return false; }
    read_pico_sd_info_t info = {0};
    esp_err_t err = read_pico_sd_get_info(&info);
    if (!info.present) s_media_recovery_requested = false;
    if (*invalidated && info.present && !s_media_recovery_requested) {
        s_media_recovery_requested = true;
        esp_err_t recovery = read_pico_sd_remount();
        if (recovery != ESP_OK && recovery != ESP_ERR_NOT_FINISHED)
            ESP_LOGW(TAG,"TF remount after insertion: %s",esp_err_to_name(recovery));
        return false;
    }
    if (err == ESP_ERR_INVALID_STATE && info.present && !*invalidated && !*mounted) {
        (void)read_pico_sd_start_probe();
        return false;
    }
    if (err == ESP_ERR_NOT_FINISHED) return false;
    // 可信挂载不因一次容量/检测通信错误而失效。/ A trusted mount survives transient detection/space faults.
    if(err!=ESP_OK&&info.mounted)return false;
    bool ready = err == ESP_OK && info.mounted;
    bool lost = *mounted && !ready;
    bool gained = !*mounted && ready;
    *mounted = ready;
    if (ready) { *invalidated = false; s_media_recovery_requested = false; }
    if (gained) {
        esp_err_t installed = bundled_assets_install();
        if (installed != ESP_OK) ESP_LOGW(TAG,"Optional artwork install deferred: %s",esp_err_to_name(installed));
        if (current->on_media_ready) current->on_media_ready(ctx);
    }
    if (!lost) return false;
    *invalidated = true;
    s_media_recovery_requested = false;
    if (current->on_media_lost) current->on_media_lost(ctx);
    ttf_font_unload();
    ttf_font_open_builtin();
    ui_text_set_system_font(false);
    return true;
}

// 返回目标先清成当前主页面，阅读回调再补充文件路径。/ Start with the current root; the reader callback supplies its path.
static void prepare_lock_resume(app_ctx_t *ctx,const app_desc_t *current){
    operation_log_event(OPLOG_SLEEP,1,0,0,0,0);
    operation_log_finish();
    unsigned tab=0;for(unsigned i=0;i<4;++i)if(app_at(i)==current)tab=i;
    sleep_resume_set_target(tab,NULL);
    if(current->on_before_lock)current->on_before_lock(ctx);
}

// 电源动作先保存当前页面，再定稿一张不带时钟的静态画面；避免关机后留下会误读的冻结时间。
// Save the current page first, then settle a clock-free static frame so shutdown never leaves a misleading frozen time.
static void run_power_action(app_ctx_t *ctx, const app_desc_t *current, bool restart) {
    if (current->on_before_lock) current->on_before_lock(ctx);
    operation_log_event(OPLOG_SLEEP,2,restart,0,0,0);
    operation_log_finish();
    ui_power_final_draw(ctx->fb, restart);
    guard_draw_result(ctx->hl, update_display_full(ctx->hl));
    app_lock_wait_key_idle(800);
    epd_poweroff();
    if (restart) app_restart_host();
    app_enter_host_sleep(APP_SLEEP_OFF);
}

void app_loop_run(const app_loop_config_t* config) {
    const app_desc_t* current = config->first_app != NULL
        ? config->first_app
        : app_home_page();

    cst836u_info_t touch_info = { 0 };
    cst836u_get_info(config->tp, &touch_info);
    cst836u_touch_t latest = { 0 };

    app_ctx_t ctx = {
        .hl = config->hl,
        .fb = config->fb,
        .acc = config->acc,
        .tp = config->tp,
        .sensor_ready = config->sensor_ready,
        .continuous_ready = continuous_du_init(),
        .touch = &latest,
        .touch_info = &touch_info,
    };

    bool was_touched = false;
    bool menu_open = false;
    ui_gesture_t gesture = {0};
    ui_gesture_t power_gesture = {0};
    bool power_dialog_open = false;
    int menu_pressed = UI_MENU_HIT_NONE;
    menu_feedback_t feedback = {0};
    int menu_leaf = 0;
    const app_desc_t* return_app = NULL;
    int return_leaf = 0, return_menu_leaf = 0;
    bool return_to_menu = false;
    int held_key = -1;
    int64_t held_since_ms = 0;
    int64_t last_lock_poll_ms = 0;
    int64_t last_font_retry_ms = 0;
    int64_t last_media_poll_ms = 0;
    int64_t last_network_poll_ms = 0;
    int64_t last_activity_ms=esp_timer_get_time()/1000,last_idle_poll_ms=0;
    bool idle_suspended=false;
    read_pico_sd_info_t initial_media = {0};
    (void)read_pico_sd_get_info(&initial_media);
    bool media_mounted = initial_media.mounted || (ttf_font_ready() && !ttf_font_is_builtin());
    bool media_invalidated = false;
    if (initial_media.mounted && !usb_storage_active()) (void)bundled_assets_install();
    s_media_recovery_requested = false;
    read_pico_pmu_suppress_key_until_release();
    app_lock_ignore_for(APP_LOCK_IGNORE_BOOT_MS);

    // The SD probe starts during board setup and is usually ready by the first product frame.
    // Retry here so the very first bookshelf paint already has a full CJK system face.
    if(!config->reader_resume)try_load_saved_sd_font(false);
    if (current->on_enter != NULL) current->on_enter(&ctx);
    poll_media(&ctx, current, &media_mounted, &media_invalidated);
    // 首帧必须整屏 GC16：fb 里还是 app_main 画的开机图，DU 盖不掉。
    // First frame must be full GC16: fb still holds the splash; DU cannot cover it.
    app_present(&ctx, current, APP_REDRAW_FULL);
    ESP_LOGI(TAG, "UI ready on %s", current->title);

    while (true) {
        cst836u_touch_t touch = { 0 };
        int64_t input_start=esp_timer_get_time();
        esp_err_t err = cst836u_read(config->tp, &touch);
        int input_us=(int)(esp_timer_get_time()-input_start);
        if(err!=ESP_OK||input_us>2000)operation_log_event(OPLOG_READ,err,touch.count,0,0,input_us);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "CST836U read failed: %s", esp_err_to_name(err));
            memset(&touch, 0, sizeof(touch));
        }

        const bool pressed = touch.touched && !was_touched;
        const bool released = !touch.touched && was_touched;
        operation_log_sample(&touch,err,pressed,released,app_book_reader_body_visible());
        debounce_touch(&latest, &touch, released);
        ctx.now_ms = esp_timer_get_time() / 1000;
        if(err==ESP_OK&&(touch.touched||released))last_activity_ms=ctx.now_ms;
        if (ctx.now_ms - last_network_poll_ms >= 500) {
            last_network_poll_ms = ctx.now_ms;
            read_pico_transfer_service_poll();
        }
        ctx.pressed = pressed;
        ctx.released = released;
        ctx.consumed = false;
        ctx.request_app = NULL;
        ctx.request_menu = false;
        ctx.request_return = false;
        bool selected_from_menu = false;
        const bool power_input_owned = power_dialog_open;

        if (ctx.now_ms - last_media_poll_ms >= MEDIA_POLL_INTERVAL_MS) {
            last_media_poll_ms = ctx.now_ms;
            if (poll_media(&ctx, current, &media_mounted, &media_invalidated)) {
                held_key = -1;
                cancel_gesture(&ctx, current, &gesture);
                menu_pressed = UI_MENU_HIT_NONE;
                ctx.consumed = true;
                ctx.pressed = ctx.released = false;
                was_touched = touch.touched;
                if (menu_open) present_menu(&ctx, current, menu_leaf, &feedback);
                else app_present(&ctx, current, APP_REDRAW_FULL);
                // 本轮旧输入不再触发动作，下一轮恢复正常事件处理。
                // Discard this tick's stale input, then resume normal dispatch next tick.
                operation_log_poll(err==ESP_OK&&!touch.touched&&!usb_storage_active());
        vTaskDelay(pdMS_TO_TICKS(LOOP_TICK_MS));
                continue;
            }
        }

        if (power_input_owned && err == ESP_OK) {
            ui_gesture_event_t event;
            ctx.consumed = false;
            if (ui_gesture_feed(&power_gesture, &ctx, &event)) {
                ui_power_action_t action = ui_power_dialog_handle(&event);
                if (action == UI_POWER_ACTION_CANCEL) {
                    power_dialog_open = false;
                    ui_gesture_reset(&power_gesture);
                    if (menu_open) present_menu(&ctx, current, menu_leaf, &feedback);
                    else app_present(&ctx, current, APP_REDRAW_PAGE);
                } else if (action == UI_POWER_ACTION_SHUTDOWN) {
                    if (!app_settings_staged_shutdown()) {
                        run_power_action(&ctx, current, false);
                    } else {
                        power_dialog_open = false;
                        ui_gesture_reset(&power_gesture);
                        prepare_lock_resume(&ctx,current);
                        extern const app_desc_t app_book;
                        enter_lock_and_sleep(ctx.hl, &s_lock_ignore_until_ms, ctx.acc,
                                             current == &app_book && app_book_reader_body_visible());
                        ctx.now_ms = esp_timer_get_time() / 1000;
                        last_activity_ms=ctx.now_ms;
                        poll_media(&ctx, current, &media_mounted, &media_invalidated);
                        last_media_poll_ms = ctx.now_ms;
                        ctx.pressed = false;
                        ctx.released = false;
                        app_present(&ctx, current, APP_REDRAW_PAGE);
                    }
                } else if (action == UI_POWER_ACTION_RESTART) {
                    run_power_action(&ctx, current, true);
                }
            }
            ctx.consumed = true;
        }

        if (err != ESP_OK) {
            operation_log_event(OPLOG_CANCEL,1,err,0,0,0);
            held_key = -1;
            ctx.consumed = true;
            cancel_gesture(&ctx, current, &gesture);
            ui_gesture_reset(&power_gesture);
            if (menu_pressed >= 0) menu_feedback(&ctx, current, menu_leaf, menu_pressed, false, &feedback);
            menu_pressed = UI_MENU_HIT_NONE;
        }
        if (!power_input_owned && pressed && err == ESP_OK) {
            held_key = -1;
            const int key = ui_key_hit_test(touch.x, touch.y);
            const bool handle_hit = ui_menu_handle_hit_test(touch.x, touch.y) &&
                (!current->menu_handle_enabled || current->menu_handle_enabled(&ctx));
            ctx.consumed = true;
            if (key >= 0 || handle_hit) {
                cancel_gesture(&ctx, current, &gesture);
                if (menu_pressed >= 0) menu_feedback(&ctx, current, menu_leaf, menu_pressed, false, &feedback);
                menu_pressed = UI_MENU_HIT_NONE;
            }
            if (key >= 0 && current->owns_keys && !menu_open) {
                app_redraw_t redraw = current->on_key && !(key == UI_KEY_2 && current->defer_middle_short)
                    ? current->on_key(&ctx, key) : APP_REDRAW_NONE;
                present_page(&ctx, current, &gesture, redraw);
                if (current->on_key_long && touch.count == 1) {
                    held_key = key;
                    held_since_ms = ctx.now_ms;
                }
            } else if (key == UI_KEY_2) {
                if (menu_open) {
                    feedback.updates = 0;
                    ui_draw_menu_page(ctx.fb, current, menu_leaf);
                    guard_draw_result(ctx.hl, update_display_full(ctx.hl));
                } else if (current->present != NULL && current->present(&ctx, APP_REDRAW_FULL)) {
                } else if (current->render != NULL) {
                    current->render(&ctx, ctx.fb);
                    guard_draw_result(ctx.hl, update_display_full(ctx.hl));
                }
            } else if ((key == UI_KEY_3 || handle_hit) && !usb_storage_active()) {
                menu_open = !menu_open;
                if (menu_open) {
                    menu_leaf = ui_menu_leaf_for_app(current);
                    present_menu(&ctx, current, menu_leaf, &feedback);
                } else app_present(&ctx, current, APP_REDRAW_PAGE);
            } else if (key >= 0 && menu_open) {
                int next = menu_leaf + (key == UI_KEY_1 ? -1 : 1);
                if (next >= 0 && next < ui_menu_leaf_count()) {
                    menu_leaf = next;
                    present_menu(&ctx, current, menu_leaf, &feedback);
                }
            } else if (key >= 0) {
                app_redraw_t redraw = current->on_key ? current->on_key(&ctx, key) : APP_REDRAW_NONE;
                if (redraw == APP_REDRAW_NONE)
                    ESP_LOGI(TAG, "KEY%d pressed, no action bound", key + 1);
                present_page(&ctx, current, &gesture, redraw);
            } else if (menu_open) {
                int hit = ui_menu_hit_test(touch.x, touch.y, menu_leaf);
                if (hit == UI_MENU_HIT_PREV || hit == UI_MENU_HIT_NEXT) {
                    menu_leaf += hit == UI_MENU_HIT_NEXT ? 1 : -1;
                    present_menu(&ctx, current, menu_leaf, &feedback);
                } else if (hit >= 0 && touch.count == 1) {
                    menu_pressed = hit;
                    menu_feedback(&ctx, current, menu_leaf, hit, true, &feedback);
                }
            } else if (current->on_gesture) {
                ctx.consumed = false;
            } else {
                // 旧页按下先收到 consumed=true，仅 NONE 为同轮 tick 放行。
                // Legacy press sees consumed=true; only NONE clears it for this tick.
                app_redraw_t redraw = current->on_touch
                    ? current->on_touch(&ctx, &latest) : APP_REDRAW_NONE;
                app_present(&ctx, current, redraw);
                if (redraw == APP_REDRAW_NONE) ctx.consumed = false;
            }
        }
        if (err == ESP_OK) was_touched = touch.touched;
        if (!power_input_owned && menu_open && menu_pressed >= 0) {
            int hit = ui_menu_hit_test(latest.x, latest.y, menu_leaf);
            if (touch.count > 1 || hit != menu_pressed || released) {
                int chosen = menu_pressed;
                menu_feedback(&ctx, current, menu_leaf, chosen, false, &feedback);
                menu_pressed = UI_MENU_HIT_NONE;
                if (released && err == ESP_OK && hit == chosen) {
                    menu_open = false;
                    ctx.request_app = app_at(chosen);
                    selected_from_menu = true;
                    if (ctx.request_app == current) app_present(&ctx, current, APP_REDRAW_PAGE);
                }
            }
        }
        if (!power_input_owned && !menu_open && current->on_gesture && err == ESP_OK) {
            ui_gesture_event_t event;
            if (ui_gesture_feed(&gesture, &ctx, &event)) {
                app_redraw_t redraw = current->on_gesture(&ctx, &event);
                present_page(&ctx, current, &gesture, redraw);
                if (redraw != APP_REDRAW_NONE) ctx.consumed = true;
            }
        }

        ctx.now_ms = esp_timer_get_time() / 1000;
        rails_idle_check(ctx.now_ms);

        // 电源键短按默认锁屏；阅读正文可选择将它用于下一页。
        // A short power press normally locks; the reader body may use it for the next page.
        if (read_pico_pmu_ready() && !current->holds_pmu && !usb_storage_active()
            && ctx.now_ms - last_lock_poll_ms >= APP_LOCK_POLL_MS) {
            last_lock_poll_ms = ctx.now_ms;
            read_pico_pmu_key_action_t key_action = read_pico_pmu_take_key_action();
            const pmu_snapshot_t *battery = read_pico_pmu_get();
            time_t battery_time = time(NULL);
            if (battery_time < 1704067200 && battery && battery->time_synced) battery_time = battery->unix_sec;
            unsigned battery_mv = battery ? (battery->quick_ok ? battery->qb_mv : battery->battery_mv) : 0;
            if (battery_time >= 1704067200 && (uint64_t)battery_time <= UINT32_MAX)
                battery_history_observe((uint32_t)battery_time, pmu_battery_percent(battery), battery_mv,
                                    pmu_battery_charging(battery), media_mounted);

            if (key_action != READ_PICO_PMU_KEY_NONE) {
                last_activity_ms=ctx.now_ms;
                if (ctx.now_ms < s_lock_ignore_until_ms) {
                    ESP_LOGI(TAG, "ignore boot power-key action %d", (int)key_action);
                } else if (key_action == READ_PICO_PMU_KEY_LONG) {
                    held_key = -1;
                    cancel_gesture(&ctx, current, &gesture);
                    if (menu_pressed >= 0) menu_feedback(&ctx, current, menu_leaf, menu_pressed, false, &feedback);
                    menu_pressed = UI_MENU_HIT_NONE;
                    extern const app_desc_t app_book;
                    bool reader_power_lock = !menu_open && current == &app_book &&
                        app_book_reader_body_visible() && app_settings_reader_power_turn();
                    if (reader_power_lock) {
                        prepare_lock_resume(&ctx,current);
                        enter_lock_and_sleep(ctx.hl, &s_lock_ignore_until_ms, ctx.acc, true);
                        ctx.now_ms = esp_timer_get_time() / 1000;
                        last_activity_ms=ctx.now_ms;
                        poll_media(&ctx, current, &media_mounted, &media_invalidated);
                        last_media_poll_ms = ctx.now_ms;
                        ctx.consumed = true;
                        ctx.pressed = false;
                        ctx.released = false;
                        app_present(&ctx, current, APP_REDRAW_PAGE);
                    } else {
                        power_dialog_open = true;
                        ui_gesture_reset(&power_gesture);
                        ui_power_dialog_draw(ctx.fb);
                        guard_draw_result(ctx.hl, update_display_area_with(
                            ctx.hl, &E0470_WAVEFORM, MODE_GL16, ui_power_dialog_rect()));
                    }
                } else if (!power_dialog_open) {
                    held_key = -1;
                    cancel_gesture(&ctx, current, &gesture);
                    if (menu_pressed >= 0) menu_feedback(&ctx, current, menu_leaf, menu_pressed, false, &feedback);
                    menu_pressed = UI_MENU_HIT_NONE;
                    app_redraw_t power_redraw = !menu_open && current->on_power_short
                        ? current->on_power_short(&ctx) : APP_REDRAW_NONE;
                    if (power_redraw != APP_REDRAW_NONE) {
                        present_page(&ctx, current, &gesture, power_redraw);
                        ctx.consumed = true;
                    } else {
                        prepare_lock_resume(&ctx,current);
                        extern const app_desc_t app_book;
                        enter_lock_and_sleep(ctx.hl, &s_lock_ignore_until_ms, ctx.acc,
                                             !menu_open && current == &app_book && app_book_reader_body_visible());
                        ctx.now_ms = esp_timer_get_time() / 1000;
                        last_activity_ms=ctx.now_ms;
                        poll_media(&ctx, current, &media_mounted, &media_invalidated);
                        last_media_poll_ms = ctx.now_ms;
                        ctx.consumed = true;
                        ctx.pressed = false;
                        ctx.released = false;
                        // 醒来还在同一页，重画一次免得留着锁屏图。
                        // Still the same page; redraw so the lock image does not stay.
                        if (menu_open) present_menu(&ctx, current, menu_leaf, &feedback);
                        else app_present(&ctx, current, APP_REDRAW_PAGE);
                    }
                }
            }
        }

        // 设置里存的字体在 SD 卡上，开机时卡可能还没挂好，这里定期重试。
        // The saved font lives on the card; retry until the mount is ready.
        // The saved font lives on the card; retry until the mount is ready.
        if (!power_dialog_open && !usb_storage_active() && current != &app_transfer &&
            ctx.now_ms - last_font_retry_ms >= FONT_RETRY_INTERVAL_MS) {
            last_font_retry_ms = ctx.now_ms;
            if (try_load_saved_sd_font(!media_invalidated)) {
                held_key = -1;
                cancel_gesture(&ctx, current, &gesture);
                ctx.consumed = true;
                menu_pressed = UI_MENU_HIT_NONE;
                if (menu_open) {
                    present_menu(&ctx, current, menu_leaf, &feedback);
                } else {
                    app_present(&ctx, current, APP_REDRAW_FULL);
                }
                ESP_LOGI(TAG, "TTF font ready");
            }
        }

        if (!power_dialog_open && released && held_key == UI_KEY_2 && ui_key_hit_test(latest.x, latest.y) == UI_KEY_2 &&
            current->defer_middle_short && !menu_open &&
            !ctx.request_app && !ctx.request_menu && !ctx.request_return) {
            int key = held_key;
            held_key = -1;
            ctx.consumed = true;
            app_redraw_t redraw = ctx.now_ms - held_since_ms >= UI_LONG_PRESS_MS
                ? current->on_key_long(&ctx, key) : current->on_key(&ctx, key);
            present_page(&ctx, current, &gesture, redraw);
        }
        if (!power_dialog_open && held_key >= 0) {
            if (menu_open || ctx.request_app || ctx.request_menu || ctx.request_return || !touch.touched ||
                touch.count != 1 || ui_key_hit_test(touch.x, touch.y) != held_key ||
                ctx.now_ms < held_since_ms) {
                held_key = -1;
            } else if (!pressed && ctx.now_ms - held_since_ms >= UI_LONG_PRESS_MS) {
                int key = held_key;
                held_key = -1;
                ctx.consumed = true;
                present_page(&ctx, current, &gesture, current->on_key_long(&ctx, key));
            }
        }
        if (!power_dialog_open && !menu_open && !ctx.request_app && !ctx.request_menu && !ctx.request_return && current->on_tick != NULL) {
            app_redraw_t redraw = current->on_tick(&ctx);
            if (redraw == APP_REDRAW_PAGE || redraw == APP_REDRAW_FULL) held_key = -1;
            present_page(&ctx, current, &gesture, redraw);
        }
        if (menu_open && feedback.updates > 0
            && ctx.now_ms - feedback.last_ms >= UI_SETTLE_IDLE_MS) {
            guard_draw_result(ctx.hl, update_display_area_with(
                ctx.hl, &E0470_WAVEFORM, MODE_GL16, feedback.area));
            feedback.updates = 0;
        }
        if (!menu_open) feedback.updates = 0;
        // 返回来源优先；普通请求仍按切页优先处理。
        // Return requests win; ordinary requests still prioritize page switches.
        // USB MSC 持有 TF 卡时禁止任何页面切换；必须先安全停止并重新挂载。
        // Never navigate while USB MSC owns the card; stop and remount it first.
        if (usb_storage_active()) {
            ctx.request_return = false;
            ctx.request_app = NULL;
            ctx.request_menu = false;
        }
        if (!power_dialog_open && (ctx.request_return || ctx.request_app || ctx.request_menu)) {
            last_activity_ms=ctx.now_ms;
            held_key = -1;
            const app_desc_t* next = ctx.request_app;
            const bool go_back = ctx.request_return;
            cancel_gesture(&ctx, current, &gesture);
            menu_pressed = UI_MENU_HIT_NONE;
            ctx.request_app = NULL;
            ctx.request_menu = false;
            ctx.request_return = false;
            ctx.consumed = true;
            if (go_back) {
                menu_open = return_app ? return_to_menu : true;
                menu_leaf = return_app ? return_menu_leaf : ui_menu_leaf_for_app(current);
                if (return_app) {
                    if (current->on_exit) current->on_exit(&ctx);
                    current = return_app;
                    return_app = NULL;
                    app_font_activate_system();
                    if (current->on_enter) current->on_enter(&ctx);
                    // 初始化后恢复通用页码，避免 on_enter 的默认页码覆盖来源。
                    // Restore the shared leaf after initialization overrides its default.
                    ctx.leaf = return_leaf;
                }
                if (menu_open) present_menu(&ctx, current, menu_leaf, &feedback);
                else app_present(&ctx, current, APP_REDRAW_PAGE);
            } else if (next) {
                if (next != current) {
                    return_app = current;
                    return_leaf = ctx.leaf;
                    return_to_menu = selected_from_menu;
                    return_menu_leaf = menu_leaf;
                }
                menu_open = false;
                switch_to(&ctx, &current, next);

            } else {
                menu_open = true;
                menu_leaf = ui_menu_leaf_for_app(current);
                present_menu(&ctx, current, menu_leaf, &feedback);
            }
        }
        // 空闲倒计时只由真实输入重置，后台页面刷新不延长阅读亮屏。/ Only input resets idle time; periodic redraws do not keep the reader awake.
        if(ctx.now_ms-last_idle_poll_ms>=1000){
            last_idle_poll_ms=ctx.now_ms;
            unsigned minutes=app_settings_idle_sleep_minutes();
            bool blocked=power_dialog_open||current->holds_pmu||usb_storage_active()||err!=ESP_OK;
            if(minutes&&current->prevent_idle_sleep)blocked=blocked||current->prevent_idle_sleep(&ctx);
            if(!minutes||blocked){last_activity_ms=ctx.now_ms;idle_suspended=true;}
            else if(idle_suspended){last_activity_ms=ctx.now_ms;idle_suspended=false;}
            else if(!touch.touched&&ctx.now_ms-last_activity_ms>=(int64_t)minutes*60000){
                held_key=-1;cancel_gesture(&ctx,current,&gesture);
                if(menu_pressed>=0)menu_feedback(&ctx,current,menu_leaf,menu_pressed,false,&feedback);
                menu_pressed=UI_MENU_HIT_NONE;
                prepare_lock_resume(&ctx,current);
                extern const app_desc_t app_book;
                enter_lock_and_sleep(ctx.hl,&s_lock_ignore_until_ms,ctx.acc,!menu_open&&current==&app_book&&app_book_reader_body_visible());
                ctx.now_ms=esp_timer_get_time()/1000;last_activity_ms=last_idle_poll_ms=ctx.now_ms;
                poll_media(&ctx,current,&media_mounted,&media_invalidated);last_media_poll_ms=ctx.now_ms;
                ctx.consumed=true;ctx.pressed=ctx.released=false;was_touched=false;
                if(menu_open)present_menu(&ctx,current,menu_leaf,&feedback);
                else app_present(&ctx,current,APP_REDRAW_PAGE);
            }
        }
        app_time_service_poll(ctx.now_ms,err==ESP_OK&&!touch.touched&&!ctx.released&&!ctx.consumed&&
            !power_dialog_open&&!usb_storage_active()&&!current->holds_pmu);
        operation_log_poll(err==ESP_OK&&!touch.touched&&!usb_storage_active());
        vTaskDelay(pdMS_TO_TICKS(LOOP_TICK_MS));
    }
}
